# II. Factibilidad Propuesta de Solución
## 1. Factibilidad técnica
Los estudios de Factibilidad técnica refieren a la posibilidad de realizar el proyecto bajo la perspectiva de varios factores. Estos factores serán explicados a continuación:

### 1.1. Tecnología
La tecnología a ser empleada dentro del desarrollo del proyecto será la codificación en PHP. Esto quiere decir que se va a trabajar sobre tecnologías existentes. PHP se trata de un lenguaje de código altamente popular, utilizado aproximadamente por 8 de cada 10 páginas, por lo que es perfectamente aceptable su utilización en este sistema.

### 1.2. Infraestructura
Las instalaciones requeridas para el proyecto no son tomadas en consideración, pues se plantea la utilización de un servicio de Hosting para el sitio web. Dicho de otra forma, ya que una empresa de terceros va a tomar control de la infraestructura, no es necesario para el proyecto preocuparse de los equipos, sino la preocupación yace en encontrar un Host que soporte el sitio web que se plantea implementar.

### 1.3. Legal
Tomando como referencia la revisión a los estipulados del Código de Buenas Prácticas de la Cámara de Comercio de Santiago, se encuentra que el sitio web a desarrollar no incumple con norma alguna dentro del código, ni las leyes citadas dentro del mismo Código. En referencia al código utilizado para llevar a cabo la solución, no se dispone de códigos que requieran licencias adicionales o se encuentren protegidas por derechos de autor.

## 2. Factibilidad económica
Para determinar si el proyecto es factible desde el punto de vista económico, es necesario comparar los costos de desarrollo junto a los ingresos de la empresa en cuestión, para determinar si el impacto económico del software es de una magnitud que pueda ser manejada por la empresa

### 2.1. Recursos
Para poner en marcha el sistema, se predispone de los siguientes recursos:

#### 2.1.1. Hardware

Asus VivoBook Pro | $ 499.990 
---- | ----
Procesador | Intel® Core i7-7700HQ
Memoria RAM | 8GB DDR4-SDRAM
Gráfica | NVIDIA GeForce GTX 1050 4 Gb
Almacenamiento | 512 Gb SSD
Sistema operativo | Windows 10 Home 64-bit Edition

***Tabla 1**: Hardware de desarrollo*

#### 2.1.2. Software

Nombre | Precio
---- | ----
Sublime Text Editor | Gratuito
Xampp | Gratuito

***Tabla 2**: Software de desarrollo*

Debido a los recursos predispuestos, se puede trabajar sin incurrir en costos adicionales; se cuenta con un equipo apropiado para desarrollar bajo las condiciones estipuladas, (Código en PHP) y proveer un ambiente bajo el cuál la aplicación pueda funcionar. Ambos Sublime Text y Xampp son programas de libre acceso, por ende, no se requiere de licencia para ser utilizados como herramienta para programar.

### 2.2. Adquisiciones
#### 2.2.1. Red

Tipo | Precio
---- | ----
Dominio en [Nic.cl](https://www.nic.cl/)  | $ 9.950 /año
Hosting | $ 9.900 /año
**Total** | $ 19.850

***Tabla 3**: Recursos de red*

Se debe considerar la contratación de un servicio de hosting, así como la adquisición de un dominio en Nic.cl. La empresa EntreTenedores se encuentra capaz de cubrir estos costos.

### 2.3. Costos de Horas Hombre
#### 2.3.1. Sueldos
Roles | Costo por Hora | Sueldo | Total |
------|----------------|--------|-------|
Ingeniero en Informática (2) | $ 24.250 | $ 970.000 | $ 3.880.000

***Tabla 4**: Sueldos*

#### 2.3.2. Costos Fijos y Variables
Los valores a continuación están considerados como el agregado de los costos de las dos personas que conforman el equipo de desarrollo

Costo | Tipo | Valor Mensual | Valor a 4 Meses
------|------|---------------|----------------
Teléfono | Fijo | $ 15.000 | $ 60.000
Internet | Fijo | $ 28.000 | $ 112.000
Electricidad | Variable | $ 40.000 | $ 160.000
Transporte | Variable | $ 20.800 | $ 83.200
 | | | **Total** | $415.200
 
 ***Tabla 5**: Costos Fijos y Variables*

### 2.4. Totales
Costo | Precio
------|-------
Hardware | $ 499.990
Software | $ 0
Red | $ 19.850
Sueldos | $ 3.880.000
Fijos | $ 172.000
Variables | $ 240.200
**Total** | $ 4.820.040

***Tabla 6**: Costos totales*

## 3. Factibilidad implementativa
Debido a que la Empresa contraparte no impone restricciones alguna referentes al desarrollo de la aplicación, se considera que la implementación de la aplicación es factible sin requerir mayor análisis.

# Referencias Bibliográficas
Cámara de Comercio de Santiago. (s.f.). Código Buenas Prácticas. Recuperado desde https://www.ccs.cl/prensa/publicaciones/CodigoBuenasPracticas_02.pdf
