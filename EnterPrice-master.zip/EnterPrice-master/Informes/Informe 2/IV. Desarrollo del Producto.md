# IV. Desarrollo del Producto
## 1. Dirección de proyecto
### 1.1. Alcance del proyecto
El proyecto engloba las tareas necesarias para la creación de un software de cotización, y levantamiento de un sitio web para la empresa EntreTenedores, que integre el software de cotización dentro de las funciones accesibles por el usuario final. Este software de cotización no contempla transacciones monetarias, pues éstas se traducen en grandes sumas de dinero.

#### 1.1.1. Desglose de trabajo
* **Fase de desarrollo conceptual**: En esta fase, se realiza una lluvia de ideas para considerar la forma que va a tomar el software. Durante este proceso, se plantean diferentes posibilidades sobre el tipo de software a desarrollar, y la empresa al que va dirigido.
* **Fase de planificación**: Durante esta fase, el proyecto se planifica de manera minuciosa, detallando el plan a seguir en el futuro. Es la fase concurrente, en la cual se establece el equipo, fechas y presupuestos del proyecto, de forma que todo esté bajo control y tomado en cuenta para el futuro.
* **Fase de desarrollo**: Esta fase es aquella durante la cuál el proyecto comienza a tomar forma y cobrar vida. Durante esta fase, se programa el sitio web, y se levantan sus características, así también como su aspecto visual y otros detalles. Es la fase más extensa, debido a la mayor complejidad que conlleva el programar el sistema. 
* **Fase de depuración y pruebas**: Durante este período, se pone a prueba la robustez del sistema, observando bajo qué situaciones falla, con la finalidad de captar dichos errores antes de que el proyecto se considere listo para ser mostrado al público. Durante esta fase, se finaliza el aspecto visual del sitio web.
* **Fase de implementación y capacitación**: La fase final del proyecto corresponde al levantamiento de la aplicación en el hosting designado, bajo el dominio adquirido por el cliente. Esta fase también contempla la capacitación del personal de la empresa, de manera que sean conscientes de cómo utilizar la aplicación en su totalidad.

### 1.2. Equipo de proyecto
El equipo de trabajo está compuesto por **César Elías Mansilla Sánchez**, tomando el cargo de *Administrador de Gestión*, y **Nicolás Eduardo Orellana Ciuffardi**, tomando los roles de *Jefe de Proyecto* y *Secretario Documentador*.
Los cargos fueron distribuidos a lo largo del equipo en base a los talentos y capacidades de los integrantes del equipo de trabajo:
* **César Mansilla** fue asignado el rol de *Administrador de Gestión* debido a su mayor conocimiento y proficiencia en el desarrollo de aplicaciones web, ofreciendo experiencia previa en el tipo de solución que se busca implementar dentro de esta empresa.
* **Nicolás Orellana** fue asignado el rol de *Jefe de Proyecto* debido a su contacto directo con la empresa y los stakeholders. Además, él toma el rol de *Secretario Documentador*, por su mayor afinidad a la escritura y la buena gramática, y estructuración formal de documentos.

### 1.3. Comunicaciones del proyecto
El equipo de trabajo se encuentra en constante contacto con el cliente por medio de mensajería instantánea Whatsapp. De esta forma, es posible reaccionar de manera instantánea a solicitudes de cambio que puedan surgir para el sistema. Internamente, el equipo se mantiene en contacto por medio de Slack, con la finalidad de utilizar la plataforma con un medio de evidenciar los acontecimientos referentes al proyecto. Además, se cuenta con un Bot en Slack que automatiza la tarea de informar cambios dentro del código del sistema, además de actualizaciones a las tareas planificadas cada semana.

### 1.4. Cronograma e hitos
El proyecto está comprendido entre el Lunes 12 de Agosto de 2019 y el Martes 5 de Noviembre de 2019

Hito | Fecha Límite
---- | ----
Fase de desarrollo conceptual | 19 de Agosto
Fase de planificación | 3 de Septiembre
Fase de desarrollo | 15 de Octubre
Fase de depuración y pruebas | 29 de Octubre
Fase de implementación y capacitación | 5 de Noviembre

***Tabla 5**: Cronograma*

La Fase de desarrollo puede subdividirse de la siguiente manera:

Hito | Fecha Límite
---- | ----
Definición Layout del sitio | 10 de Septiembre
Integración Carrusel de Fotos | 17 de Septiembre
Funcionalidad Cotización | 8 de Octubre
Funcionalidad Calendario | 15 de Octubre

***Tabla 6**: Cronograma Fase de desarrollo*

### 1.5. Riesgos del proyecto
Código | Riesgo | Probabilidad | Impacto | Acción Mitigadora
-------|--------|--------------|---------|------------------
R1 | Pérdida de Interés de la Empresa | Baja | Alto | Contacto continuo con el cliente permite reducir la probabilidad de este riesgo
R2 | Pérdida de información | Muy Baja | Muy Alto | Respaldos semanales del repositorio ayudan a reducir el impacto de este riesgo
R3 | Indisponibilidad de parte del Equipo | Baja | Media | Mantener el proyecto al día, respetando la planificación según el cronograma y la carta Gantt, asegurándose de adelantar tareas en la medida de lo posible. Además, la naturaleza en línea del proyecto permite progreso incluso en situaciones que el equipo se sienta incapacitado para trabajar.

***Tabla 7**: Análisis de Riesgos*

### 1.6. Costos de proyecto
#### 1.6.1. Recursos
Para poner en marcha el sistema, se predispone de los siguientes recursos:

**Hardware**

Asus | VivoBook Pro 
---- | ----
Procesador | Intel® Core i7-7700HQ
Memoria RAM | 8GB DDR4-SDRAM
Gráfica | NVIDIA GeForce GTX 1050 4 Gb
Almacenamiento | 512 Gb SSD
Sistema operativo | Windows 10 Home 64-bit Edition

***Tabla 8**: Hardware de desarrollo*

**Software**

Nombre | Precio
---- | ----
Sublime Text Editor | Gratuito
Xampp | Gratuito

***Tabla 9**: Software de desarrollo*

Debido a los recursos predispuestos, se puede trabajar sin incurrir en costos adicionales; se cuenta con un equipo apropiado para desarrollar bajo las condiciones estipuladas, (Código en PHP) y proveer un ambiente bajo el cuál la aplicación pueda funcionar. Ambos Sublime Text y Xampp son programas de libre acceso, por ende, no se requiere de licencia para ser utilizados como herramienta para programar.

#### 1.6.2. Adquisiciones
**Red**

Tipo | Precio
---- | ----
Dominio en [Nic.cl](https://www.nic.cl/)  | $ 9.950 /año
Hosting | $ 9.900 /año

***Tabla 10**: Recursos de red*

Se debe considerar la contratación de un servicio de hosting, así como la adquisición de un dominio en Nic.cl. La empresa EntreTenedores se encuentra capaz de cubrir estos costos.

#### 1.6.3. Flujo de caja
![Flujo de Caja](https://github.com/NE-OC/EnterPrice/blob/master/Informes/Informe%202/Anexos/EnterPrice_Flux.png)

***Figura 7**: Flujo de caja*

## 2. Aseguramiento de calidad
### 2.1. Estándares y Normas
Debido a que el desarrollo de esta aplicación está planteado en la producción de una aplicación para el público general, se tomará la opinión de un grupo de *beta testers* como métrica principal a la cuál adherirse a la hora de evaluar el funcionamiento de la aplicación. Este grupo de personas será interrogado con múltiples preguntas relacionadas a la usabilidad de la aplicación, y se les solicitará calificar la aplicación del 1 al 10. Si la calificación promedio del equipo de pruebas supera a 8, entonces se considera que la aplicación es suficientemente amigable desde la perspectiva del usuario final.

### 2.2. Control de cambios
El control de cambios será gestionado por César Mansilla. A través de Git, es posible crear ramificaciones al código principal, y mantenerlas en espera hasta que sean aprobadas. De esta forma, si el resto del equipo fuera a realizar cambios, es posible para el administrador de gestión revisar el código o elementos alterados antes de que sean implementados, asegurándose que sean benignos desde la perspectiva del código.

### 2.3. Control de versiones
Las versiones de la aplicación van a cumplir con los siguientes requisitos. Serán etiquetadas en Git conforme alcancen las metas establecidas.

#### Beta 0.1
* **Layout del Sitio**: Primera versión del sitio; definición del aspecto visual

#### Beta 0.2
* **Carrusel**: Integración funcionalidad Carrusel

#### Beta 0.3
* **Cotización**: Integración funcionalidad Cotización

#### Beta 0.4
* **Floating Box**: Agregado una caja flotante que sigue al usuario junto al scroll de la página. Esta caja incluye el precio total del servicio que está seleccionando el cliente

#### Beta 0.5
* **Calendario**: Integración funcionalidad Calendario, bloqueando fechas en las que ya se tiene reservación

#### Release 1.0
* **Base de Datos Final**: La aplicación presenta los valores reales de la empresa, incluyendo especificaciones numéricas como número de invitados o costo final de los servicios a ofrecer. Además, se finaliza el aspecto visual, incluyendo fotos y CSS

### 2.4. Plan de pruebas
#### 2.4.1. Pruebas de software
Las pruebas de software se enfocarán en la robustez del sistema y la validación de los datos. Para esto, se realizará una sesión de “sabotaje” de la aplicación en un ambiente controlado. Esta sesión involucrará el ingreso minucioso de valores erróneos dentro de cualquier campo que la aplicación presente al usuario. Entiéndase por erróneo el ingreso de datos alfabéticos en campos numéricos, valores fuera de los rangos determinados por un campo numérico, valores negativos en campos que solo aceptan positivos, formato incorrecto de la dirección de correo, entre otros.

El funcionamiento esperado ante el ingreso de estos datos erróneos es que la aplicación explique al usuario, mediante un mensaje de error, que ha ingresado datos inesperados. Además, el mensaje debe aclarar al usuario los valores que se espera sean ingresados.

El funcionamiento inesperado puede manifestarse en una de dos formas: la primera, involucra la aplicación fracasando en la entrega de un mensaje de error comprensivo para el usuario. La segunda supone la caída total de la aplicación, produciendo un fallo que termine con el funcionamiento de la aplicación.

Si alguno de los casos anteriormente expuestos fuese a darse durante la sesión de “sabotaje”, inmediatamente deben realizarse alteraciones al código de forma que la aplicación sea capaz de entregar mensajes de error al usuario.


#### 2.4.2. Pruebas técnicas
Debido a que la aplicación desempeñará en un servicio de hosting, las pruebas técnicas no aplican.

## 3. Plan de Implementación y Mantención
La aplicación será subida al Hosting una vez su desarrollo haya concluído. Una vez en el Hosting, durante el primer mes, se monitoreará su desempeño dos veces por semana: la primera, entre Lunes y Viernes; la segunda, durante el Sábado o Domingo. Se espera que con estas pruebas se obtenga una referencia del funcionamiento de la aplicación durante distintos períodos de actividad. Si la aplicación fuera a presentar problemas que impidan su desempeño, se realizará un diagnóstico de forma inmediata, y a continuación, se efectuará un reinicio de la aplicación, de modo que se restauren sus funciones básicas.

## 4. Auditoría y Benchmarking
### 4.1. Plan de auditoría
Las auditorías a realizar contemplan la observación de la aplicación en funcionamiento, asegurando que los usuarios sean capaces de utilizar la aplicación de manera correcta. Para este fin, se seleccionará a un mínimo de diez personas de distintas edades, y se les solicitará realizar una cotización. Si son capaces de cumplir la tarea en menos de diez minutos, entonces se considera que la aplicación tiene éxito desde la perspectiva de experiencia de usuario.

### 4.2. Mejora continua
El plan de mejora continua contempla la actualización de la aplicación sólo si se presentasen errores críticos que impidan el correcto funcionamiento de la aplicación.
