# I. Introducción
Vivimos en una sociedad que vive constantemente enlazada con la tecnología. Día a día, este enlace se fortalece y se evidencia en nuestro constante uso de dispositivos informáticos. El ser humano persigue una existencia cómoda, dicha comodidad viéndose reflejada en el esfuerzo que se vierte en procurar un mañana más sencillo. Este escrito se enfoca en la ayuda provista al Centro de Eventos EntreTenedores, y guía al lector por el proceso de diseño de la aplicación concebida para facilitar el proceso de cotizaciones que lleva la empresa.

Este informe comprende las factibilidades del proyecto, los procesos de diseño y modelado de la solución, así como la metodología de trabajo que se utiliza para traer a la vida la solución, y monitorear su desempeño en situaciones reales y simuladas.

A través de este informe se espera que el lector pueda comprender y realizar un seguimiento del proceso requerido para planificar una solución informática para una empresa que se encuentra en una situación precaria, dejando una oportunidad de mejora en su funcionar por medio de la aplicación que se desarrollará en este informe.
