﻿# III. Diseño de la Solución
## 1. Especificación de requerimientos (IEEE 830)
Nro. | Requerimiento
-----|-----
RF01 | El sistema debe presentar un "carrusel" de imágenes
RF02 | El sistema debe ofrecer la selección de diversos servicios
RF03 | El sistema debe ofrecer la posibilidad de alterar el número de personas invitadas al evento
RF04 | El sistema debe realizar acciones especiales al superar cierto número de invitados, como aumentar el precio base del servicio, u ofrecer recompensas
RF05 | El sistema debe presentar un calendario para seleccionar la fecha del evento
RF06 | El sistema debe prohibir la selección de fechas que ya se encuentran reservadas
RF07 | El sistema debe poder modificar el valor del servicio en base a la fecha seleccionada
RF08 | El sistema debe permitir al cliente establecer la hora del evento 
RF09 | El sistema debe actualizar el precio total del servicio de forma dinámica a medida que el usuario modifique los parámetros del evento
RF10 | El sitio debe ofrecer al cliente un espacio para escribir observaciones, para solicitar servicios adicionales que podrían no estar consideradas dentro del sistema de cotización
RF11 | El sitio debe tener integración con Google Maps, de forma que el cliente pueda localizar el Centro de Eventos
RF12 | El sitio debe presentar información de contacto de la empresa
RF13 | El sitio debe informar al cliente de las normas de conducta dentro del local
RF14 | El sitio debe informar al cliente que si el evento fuera a extenderse más allá de las horas acordadas, va a incurrir un cobro adicional
RF15 | El sitio debe ofrecer al cliente la posibilidad de decorar por su cuenta 24 horas antes del evento—esto también tiene un cobro

***Tabla 1**: Requerimientos del sistema*

## 2. Especificación de restricciones
* El sitio no debe permitir al cliente realizar compras/pago en línea, solo se permite realizar cotizaciones
* El sitio no debe generar contratos, pues son de carácter presencial

## 3. Diseño de Procesos (BPMN)
**Situación Actual**
![BPMN Situación Actual](https://github.com/NE-OC/EnterPrice/blob/master/Informes/Informe%202/Anexos/EnterPrice_BPMN-current.png)
***Figura 1**: Modelo de Procesos de la Situación Actual Antes del Evento*

**Situación futura**
![BPMN Situación futura](https://github.com/NE-OC/EnterPrice/blob/master/Informes/Informe%202/Anexos/EnterPrice_BPMN-future.png)
***Figura 2**: Modelo de Procesos de la Situación Futura Antes del Evento*

El análisis de los diagramas evidencia que varias tareas, referentes al envío o recepción de información sobre el Centro de Eventos, han sido automatizadas, de manera que el cliente disfruta de una experiencia más responsiva, mientras que EntreTenedores requiere menos tiempo interactuando con el cliente en parte del procedimiento que aún no puede garantizar ingresos, liberando tiempo que puede ser utilizado en otras operaciones.
Dado que la aplicación no afectaría al proceso durante/post-Evento, no se ha modelado por motivos de claridad.

## 4. Diseño de alto nivel (UML — casos de uso)
![Casos de Uso](https://github.com/NE-OC/EnterPrice/blob/master/Informes/Informe%202/Anexos/EnterPrice_UseCases.png)

***Figura 3**: Diagrama de Casos de Uso*

Caso de Uso | Revisar Fotos 
------------|------------
Actores | Cliente
Tipo | Primario
Descripción | El cliente hace clic en los múltiples enlaces que llevan a galerías de imágenes, observando dichas imágenes

***Tabla 2**: Caso de uso Revisar Fotos*

Caso de Uso | Realizar Cotización
------------|------------
Actores | Cliente
Tipo | Primario
Descripción | El cliente interactúa con el sistema de cotizaciones, agregando o removiendo productos

***Tabla 3**: Caso de uso Realizar Cotización*

Caso de Uso | Enviar Cotización 
------------|------------
Actores | Cliente
Tipo | Primario
Descripción | El cliente envía la cotización realizada, llegando ésta a la administración de EntreTenedores

***Tabla 4**: Caso de uso Enviar Cotización*

## 5. Diseño estructural (UML — componentes, interacción)


## 6. Diseño Técnico
### 6.1. Modelo de datos
#### 6.1.1. Modelo Lógico
![Modelo Lógico](https://github.com/NE-OC/EnterPrice/blob/master/Informes/Informe%202/Anexos/EnterPrice_LModel.png)

***Figura 4**: Modelo Lógico de datos*

#### 6.1.2. Diccionario de datos
##### Tabla Categoría
* **ID**: Número de Identificación de la Categoría, a ser utilizado de manera interna por el programa.
* **Nombre**: El nombre a visualizar de la Categoría en cuestión.

##### Tabla Producto
* **ID**: Número de Identificación del Producto, a ser utilizado de manera interna por el programa.
* **Nombre**: El nombre a visualizar del Producto en cuestión.
* **Imagen**: Imagen representativa del Producto.
* **Precio**: Precio por unidad del Producto, se multiplica por la cantidad de personas que asistirán al evento.
* **Categoria**: ID de la Categoría a la que pertenece el Producto.
* **Descripción**: Descripción del Producto. Útil, por ejemplo, para servicios del menú que carezcan de nombre descriptivo, o que requieran explicación adicional.

### 6.2 Diseño de Infraestructura TI
#### 6.2.1. Topología comunicaciones
![Topología de Red](https://github.com/NE-OC/EnterPrice/blob/master/Informes/Informe%202/Anexos/EnterPrice_Topology.png)

***Figura 5**: Topología de Red*

#### 6.2.2. Modelo Lógico de Infraestructura

#### 6.2.3. Modelo de implementación
El modelo de implementación corresponde a éste de un servicio en Hosting. Esto quiere decir que se posee el Software que se desea implementar, sin embargo, no se posee el Hardware necesario para implementarlo. Es por eso que se decide contratar los servicios de una compañía externa equipada para el levantamiento de aplicaciones, alquilando el uso de sus servidores con la finalidad de ahorrar costos a corto y mediano plazo en lo que el levantamiento del sitio respecta.

### 6.3. Diseño de GUI
#### 6.3.1. Árbol de Contenidos
```
■ Homepage
├ Galería
│ ├ Bodas
│ ├ Cumpleaños
│ ├ Aniversarios
│ └ Seminarios
├ Quienes somos
├ Contacto
└ Cotización
  └ Confirmación
```
#### 6.3.2. Wireframing
![wireframe](https://github.com/NE-OC/EnterPrice/blob/master/Informes/Informe%202/Anexos/EnterPrice_Wireframe.png)

***Figura 6**: Wireframe de la aplicación*

#### 6.3.3. Guía de Estilos
**Títulos**
> Fuente: Calibri
>
> Tamaño: 24px

**Cuerpo**
> Fuente: Calibri
>
> Tamaño: 12px
### 6.4. Metodología de Desarrollo
La metodología de desarrollo se ajusta mayormente a la metodología Cascada, pues las tareas se desarrollan de manera secuencial, debido a que varias funciones de la aplicación dependen de la existencia de otras mecánicas. Sin embargo, se tiene un contacto frecuente con el cliente, lo cuál es más característico de metodologías ágiles de desarrollo como Scrum, ocasionando un híbrido en la metodología de desarrollo.
