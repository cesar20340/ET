# Objetivo General

Automatizar el sistema de cotizaciones para el Centro de Eventos Entretenedores, por medio de la creación de un sitio web equipado para este tipo de solicitud, con la finalidad de reducir el número de cotizaciones que no resulten en una venta exitosa.

# Objetivos Específicos

*	La toma de requerimientos a realizar incluirá un estudio de los procedimientos necesarios para contratar el servicio de la empresa, dentro de las primeras dos semanas del proyecto, con la finalidad de poseer una guía sobre las funcionalidades esperadas del sitio.
*	Al momento de lanzar el prototipo debe ser capaz de realizar cotizaciones ficticias que cumpla con el funcionamiento esperado por las pruebas de utilización, en un plazo de hasta tres meses, para poder demostrar la funcionalidad completa de la aplicación bajo un carácter experimental.
*	El Centro de Eventos consta con una amplia cantidad de insumos para realizar sus eventos se estará al corriente de cada uno de ellos, para poder poblar la base de datos, que cubra todas las opciones que ofrece el Centro de Eventos para distintos tipos de evento, en un plazo de una semana y media, con el fin de poder llevar las pruebas de la aplicación a un carácter real.
* Al tener la plataforma web, podrá ser abierta sin problemas o resultados inesperados por los navegadores compatibles con el lenguaje de programación, con la finalidad de asegurarse que la aplicación esté lista para ser utilizada por el público, en un lapso de un mes aproximadamente.
