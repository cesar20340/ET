# III. Definición del Proyecto
## 1. Marco Teórico
Como conocimiento previo a la hora de leer este documento, se espera que el lector conozca superficialmente los siguientes conceptos explicados a continuación: Servidor, Hosting, HTML, PHP, SQL, Apache, XAMPP, y SublimeText

### Levantamiento de páginas web
#### Servidor
Se denomina Servidor al equipo que se encuentra procesando información, de forma que no sea necesario poner la carga de trabajo en los equipos que visualicen finalmente dicha información. El equipo que visualiza la información es denominado "Equipo Cliente". En este contexto, se utiliza la palabra Servidor para referirse a los procesos que son realizados por el equipo Host

#### Hosting
El Hosting web se refiere a la práctica de dejar un sitio web en un equipo designado para disponibilizar el sitio web en cuestión por la mayor cantidad de tiempo posible. Normalmente, se contrata la ayuda de empresas terceras, aunque empresas más grandes pueden ser su propio Host.

### Lenguajes de código
#### HTML
HTML significa **H**yper**t**ext **M**arkdown **L**anguage. Es el lenguaje de código que utilizan los navegadores web para interpretar sitios web y mostrarlos al usuario. Su utilización es estándar en la industria; todo sitio web requiere componentes HTML de algún tipo, independiente del lenguaje de programación utilizado "tras bambalinas" por el sitio.

#### PHP
PHP es un acrónimo recursivo que significa **P**HP **H**ypertext **P**reprocessor. Es un lenguaje de código caracterizado por procesar el código directamente en el Servidor, enviando al Equipo Cliente solo HTML. La ventaja de utilizar PHP en lugar de otros lenguajes de programación, es que el Equipo Cliente no podrá ver el código que se emplea para lograr el resultado que se ve en pantalla.

#### SQL
SQL significa **S**tructured **Q**uery **L**anguage. Es un lenguaje de código utilizado por Bases de Datos para ingresar, editar y eliminar la información contenida en ellas. Es también, estándar de la industria el utilizar SQL de algún modo u otro en sitios web o programas que administran información que deba perdurar a lo largo del tiempo.

### Entornos de desarrollo
#### Apache
Apache es un sistema operativo de código abierto, lo que quiere decir que cualquiera puede tomar el código y modificarlo a su antojo. Esto resulta en que Apache sea extremadamente popular y maleable, habiendo múltiples alternativas que se ajusten a las necesidades de cada usuario en particular, sin necesidad de tener experiencia alguna en código.

#### XAMPP
XAMPP es una versión de Apache que, junto a otras características, incluye soporte para PHP, disponible para Windows. Es gratuito y su principal meta es hacer Apache mucho más accesible, sin escatimar en funciones y posibles opciones y ajustes

#### SublimeText
SublimeText es el editor de texto que se utilizará para programar el sitio web. Sus ventajas sobre otros programas es su alta compatibilidad con varios lenguajes de programación—PHP incluido—y la capacidad de administrar archivos dentro de subcarpetas de manera sencilla y rápida 

## 2. Solución Tecnológica
### 2.1. Formulación
Se propone la creación de un sitio web personalizado para Entretenedores. Este sitio web busca elevar a la empresa al estándar de su competencia y del rubro, ofreciendo un "carousel" que presente imágenes en una rotación interactiva, información básica de la empresa, tales como la información de contacto, Misión, Visión y Valores, e información de contacto con la empresa.

El valor agregado, que busca dar una delantera a Entretenedores como empresa, es la integración de un sistema de Cotización interactiva. Este sistema busca guiar a un cliente por el proceso de realizar una cotización, para poder darse una idea del costo del servicio que busca contratar, y expeditar el proceso de contacto con la administración de Entretenedores.

El proceso es el siguiente: primeramente, se le ofrece al cliente la opción de seleccionar una plantilla, no distinto a la característica ofrecida por programas de Microsoft Office, ayudando al usuario a agilizar su trabajo si deseara seguir esta plantilla. Estas plantillas pueden ser, por ejemplo, enfocadas a Cumpleaños, Celebraciones de Boda, Aniversarios, u otras Fiestas. Naturalmente, el cliente también puede optar por no utilizar una plantilla y trabajar desde cero. También se solicita al cliente establecer la cantidad de invitados, así como una fecha para el evento. La fecha del evento es definida por medio de un calendario interactivo; este calendario tiene la característica especial de inhabilitar las fechas que ya se encuentran bajo reservación por la empresa, informando al cliente la razón por la cuál la fecha no se encuentra disponible.

Una vez seleccionada la plantilla, se le mostrará al cliente los servicios implicados por la plantilla. En otras palabras, se le informará al cliente el servicio básico que se presenta para el tipo de evento que le gustaría llevar a cabo. Además, se le pregunta al cliente si desea hacer cambios a la plantilla, en caso de que se encuentre disconforme y desee contratar más características, o si considera que algo ofrecido resulta redundante y puede ser eliminado para mantener el presupuesto bajo control.

Si el cliente decide que desea realizar cambios a la plantilla, o si el cliente prefirió no usar plantilla alguna en primer lugar, será llevado a una pantalla con varias categorías. Estas categorías desplegables buscan guiar al cliente por el proceso de personalizar el evento a su gusto, permitiéndole marcar y desmarcar las casillas que representan cada servicio, ajustar el número de invitados, y otras opciones de personalización, mostrando al cliente cómo el precio cambia en tiempo real.

Una vez finalizada la cotización, el cliente puede ingresar, enviarla como email a la administración. A partir de ese punto, el contacto con la administración de la empresa vuelve a su estado original; se contactará al cliente de forma manual y personal por WhatsApp, pues es necesario especificar ciertos acuerdos de manera directa.

**Beneficios**
* Mayor exposición al internet, facilitando su independencia y capacidad de figurar como sitio único frente a motores de búsqueda
* Ambiente personalizado y a medida de la empresa, logrando expresar y entregar de manera precisa la información que los clientes necesitan para decidir si contratar el servicio, al mismo tiempo que se entrega una primera impresión con cimientos más sólidos
* Expeditación del proceso de cotización, ofreciendo una opción adicional que permite al cliente formar expectativas sobre qué involucra el servicio
* Ahorro de tiempo substancial, reduciendo la cantidad de cotizaciones nulas debido a información que no se encuentra disponible de manera pública

### 2.2. Alcance
El proyecto abarca la creación del sitio y la programación del sistema de cotización. Es estrictamente necesario poner énfasis en la palabra "**Cotización**". El sistema va a guiar al usuario en la selección de varios servicios de una lista, ver su precio, y cómo aumenta el costo general de la los servicios seleccionados. Sin embargo, una vez hecho esto, no se le va a permitir al usuario la compra y/o pago directo de los productos seleccionados. Debido al alto costo del servicio, junto con la naturaleza planificada del mismo, la aplicación enviará el pedido del cliente directamente a la administración, con la finalidad de ser revisado y posteriormente contactar al cliente, estableciendo y confirmando de manera sólida el evento venidero.

## 3. Impacto de la solución
### 3.1. Proceso de negocio afectado
La instauración de este sistema presentará un impacto en los procesos de publicidad del servicio, y la venta del servicio; ambos procesos cruciales para lograr que una empresa pueda sustentarse a sí misma.

El proceso de publicidad está afectado de forma pasiva; la existencia del sitio web logrará que la empresa sea más visible para la clientela del local, permitiendo expandir el público y aumentar el número de ventas potenciales. Sin embargo, las operaciones de la empresa no se verán mayormente alteradas—no más allá de una mayor carga laboral debido al volumen mayor de solicitudes y cotizaciones.

Por otra parte, el proceso de venta del servicio se ve afectado de forma activa. Tras haber implementado el sitio, y haberlo disponibilizado al público, se puede eseperar una alteración al proceso de cotizaciones que existe en la empresa, de forma que se acomode al nuevo procedimiento ofrecido por el sitio web.

En un comienzo, es posible que el sitio sea ignorado durante un tiempo, período durante el cuál, no será aparente como ha cambiado el funcionamiento de la empresa—vale decir, se seguirá usando el sistema actual, de contactar por Facebook o WhatsApp. Sin embargo, a medida que el sitio se popularice, y la administración de la empresa comience a redirigir, sugerir, y promocionar la utilización del sitio web, es cuando se hará notar la utilidad del sitio y cómo agiliza el proceso: esencialmente, se está tomando un atajo en el proceso de cotización, en una de las etapas más prolongadas a la hora de hacer una reserva en el local.

No solo se podrán ver mejoras en el lapso de tiempo requerido para realizar una cotización, sino que también mejorará la claridad con la que el cliente puede observar el precio del servicio, y el desglose de los precios que resultan en el subtotal. Con esto en mente, la comunicación cliente-empresa puede mejorar en gran medida, estandarizando las interacciones que ocurren entre la clientela y la administración, y dejándolas en un formato claro y de fácil legibilidad

### 3.2. Registro de Interesados
Se identifican dos stakeholders principales en la instauración de este sitio web: la administración del local Entretenedores, y su clientela.

* **Administración de Entretenedores**

La Administración corresponde a *doña Patricia Elena Laguna Lizana*, cuyo actuar posibilita el funcionamiento de la empresa, ya que entre sus responsabilidades recaen en la administración y control de recursos, contratación de empleados de turno y/o jornada completa, relaciones públicas, venta del servicio, organización de eventos, entre otras responsabilidades. Este stakeholder se verá beneficiado por la existencia del sitio en la medida que éste pueda reducir la carga laboral a la que doña Patricia se enfrente, particularmente en el frente de relaciones públicas, cotización, venta, y contacto con la clientela.

* **Clientela de Entretenedores**

Se define como clientela al grupo de personas que posiblemente desearan contratar los servicios de Entretenedores. La demográfica de este grupo comprende a hombres y mujeres entre 20 a 70 años de edad. Se comprende este stakeholder beneficiado, en el sentido que se facilitará la interacción con el local, expeditando el proceso de cotización, ofreciendo un mayor grado de personalización del servicio, y ofreciendo una alternativa al sistema que la empresa emplea actualmente.

### 3.3. Indicadores de gestión
Para determinar la efectividad del sistema, una vez exista un prototipo funcional, será puesto a prueba frente a 20 personas dentro del rango etario indicado en la clientela, vale decir, diversidad de personas entre 20 a 70 años. Los sujetos de prueba serán encargados con la tarea de realizar una cotización ficticia, observando su manera de actuar durante el procedimiento. No se les proveerá asistencia o ayuda de ningún tipo durante el procedimiento, con la finalidad de asegurar que el sistema es lo suficientemetne intuitivo.
Se les dará un tiempo límite de 15 minutos para utilizar la aplicación y realizar la cotización—el tiempo promedio que se toma en realizar una cotización por WhatsApp, bajo el sistema actual.

Una vez logren realizar la cotización de forma exitosa, o pasen los 15 minutos sin que logren realizar la cotización, serán encuestados con dos preguntas abiertas y una pregunta cerrada. Las preguntas son:
* ¿Qué le gustó del sistema?
* ¿Qué mejoraría en el sistema?
* ¿Recomendaría a otras personas utilizar el sistema en su estado actual? Sí/No

Se utilizarán las primeras dos preguntas para recibir retroalimentación, mientras que la tercera y última pregunta será utilizada como indicador de éxito: se espera que al menos 4/5 de las personas contesten "Sí", dando a entender que una mayoría de las personas son capaces de hacer una cotización por medio de este sistema.

### 3.4. Niveles de servicio
El equipo se compromete a desarrollar un sitio web que conforme al cliente, su clientela, y que sea fácil de aprender y utilizar, según definido por el cumplimiento de indicadores de gestión mencionados anteriormente.

Junto a lo anterior, el equipo está comprometido a liberar un prototipo utilizable del sitio web a la fecha del 15 de Octubre. Este prototipo podrá ser levantado en un servidor local, con la finalidad de poner a prueba su funcionamiento, y depurar fallas que puedan presentarse. A esta altura, el equipo deberá entregar un prototipo que funcione sin falla alguna *si* se introducen los tipos de datos correctos en los campos oportunos (números en campos numéricos, letras en campos alfanuméricos, etcétera)

Por último, a fecha del 29 de Octubre, el equipo ha de entregar el sistema a prueba de fallos que puedan surgir debido al posible ingreso de datos erróneos o inválidos, validando campos de forma que la aplicación prohibiese al usuario ingresar valores incorrectos. 

Tras esto, y hasta el 5 de Noviembre, el equipo está encargado de levantar el sitio web en el Hosting y Dominio provistos por el cliente, y posteriormente capacitar al personal del local en la utilización del sitio. 

## 4. Objetivos del proyecto
### 4.1. Objetivo General
Automatizar el sistema de cotizaciones para el Centro de Eventos Entretenedores, por medio de la creación de un sitio web equipado para este tipo de solicitud, con la finalidad de reducir el número de cotizaciones que no resulten en una venta exitosa.

### 4.2. Objetivos Específicos
*	La toma de requerimientos a realizar incluirá un estudio de los procedimientos necesarios para contratar el servicio de la empresa, dentro de las primeras dos semanas del proyecto, con la finalidad de poseer una guía sobre las funcionalidades esperadas del sitio.
*	Al momento de lanzar el prototipo debe ser capaz de realizar cotizaciones ficticias que cumpla con el funcionamiento esperado por las pruebas de utilización, en un plazo de hasta tres meses, para poder demostrar la funcionalidad completa de la aplicación bajo un carácter experimental.
*	El Centro de Eventos consta con una amplia cantidad de insumos para realizar sus eventos se estará al corriente de cada uno de ellos, para poder poblar la base de datos, que cubra todas las opciones que ofrece el Centro de Eventos para distintos tipos de evento, en un plazo de una semana y media, con el fin de poder llevar las pruebas de la aplicación a un carácter real.
* Al tener la plataforma web, podrá ser abierta sin problemas o resultados inesperados por los navegadores compatibles con el lenguaje de programación, con la finalidad de asegurarse que la aplicación esté lista para ser utilizada por el público, en un lapso de un mes aproximadamente.

# Referencias
* The Apache Software Foundation. (s.f.). About the Apache HTTP Server Project. Recuperado desde http://httpd.apache.org/ABOUT_APACHE.html
* Apache Friends. (s.f.). About the XAMPP project. Recuperado desde https://www.apachefriends.org/es/about.html
* The PHP Group. (s.f.). ¿Qué es PHP? Recuperado desde https://www.php.net/manual/es/intro-whatis.php
* IBM. (s.f.). Acuerdos de nivel de servicio (SLA). Recuperado desde https://www.ibm.com/support/knowledgecenter/es/SSKVFR_7.6.1/com.ibm.spr.doc/sla_spr/c_sla_application.html
