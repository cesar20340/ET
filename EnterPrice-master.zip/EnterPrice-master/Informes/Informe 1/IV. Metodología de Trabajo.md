# IV. Metodología de Trabajo
## 1. Desarrollo de la solución
### 1.1. Duración y cronograma
El proyecto está comprendido entre el Lunes 12 de Agosto de 2019 y el Martes 5 de Noviembre de 2019

Hito | Fecha Límite
---- | ----
Fase de desarrollo conceptual | 19 de Agosto
Fase de planificación | 3 de Septiembre
Fase de desarrollo | 15 de Octubre
Fase de depuración y pruebas | 29 de Octubre
Fase de implementación y capacitación | 5 de Noviembre

***Tabla 1**: Cronograma*

* **Fase de desarrollo conceptual**: En esta fase, se realiza una lluvia de ideas para considerar la forma que va a tomar el software. Durante este proceso, se plantean diferentes posibilidades sobre el tipo de software a desarrollar, y la empresa al que va dirigido.
* **Fase de planificación**: Durante esta fase, el proyecto se planifica de manera minuciosa, detallando el plan a seguir en el futuro. Es la fase concurrente, en la cual se establece el equipo, fechas y presupuestos del proyecto, de forma que todo esté bajo control y tomado en cuenta para el futuro.
* **Fase de desarrollo**: Esta fase es aquella durante la cuál el proyecto comienza a tomar forma y cobrar vida. Durante esta fase, se programa el sitio web, y se levantan sus características, así también como su aspecto visual y otros detalles. Es la fase más extensa, debido a la mayor complejidad que conlleva el programar el sistema. Esta fase puede subdividirse de la siguiente manera:

Hito | Fecha Límite
---- | ----
Definición Layout del sitio | 10 de Septiembre
Integración Carrusel de Fotos | 17 de Septiembre
Funcionalidad Cotización | 8 de Octubre
Funcionalidad Calendario | 15 de Octubre

***Tabla 2**: Cronograma Fase de desarrollo*

* **Fase de depuración y pruebas**: Durante este período, se pone a prueba la robustez del sistema, observando bajo qué situaciones falla, con la finalidad de captar dichos errores antes de que el proyecto se considere listo para ser mostrado al público. Durante esta fase, se finaliza el aspecto visual del sitio web.
* **Fase de implementación y capacitación**: La fase final del proyecto corresponde al levantamiento de la aplicación en el hosting designado, bajo el dominio adquirido por el cliente. Esta fase también contempla la capacitación del personal de la empresa, de manera que sean conscientes de cómo utilizar la aplicación en su totalidad.

### 1.2. Equipo de trabajo
El equipo de trabajo está compuesto por **César Elías Mansilla Sánchez**, tomando el cargo de *Administrador de Gestión*, y **Nicolás Eduardo Orellana Ciuffardi**, tomando los roles de *Jefe de Proyecto* y *Secretario Documentador*.
Los cargos fueron distribuidos a lo largo del equipo en base a los talentos y capacidades de los integrantes del equipo de trabajo:
* **César Mansilla** fue asignado el rol de *Administrador de Gestión* debido a su mayor conocimiento y proficiencia en el desarrollo de aplicaciones web, ofreciendo experiencia previa en el tipo de solución que se busca implementar dentro de esta empresa.
* **Nicolás Orellana** fue asignado el rol de *Jefe de Proyecto* debido a su contacto directo con la empresa y los stakeholders. Además, él toma el rol de *Secretario Documentador*, por su mayor afinidad a la escritura y la buena gramática, y estructuración formal de documentos.

### 1.3. Plan de recursos
Para poner en marcha el sistema, se predispone de los siguientes recursos:

**Hardware**

Asus | VivoBook Pro 
---- | ----
Procesador | Intel® Core i7-7700HQ
Memoria RAM | 8GB DDR4-SDRAM
Gráfica | NVIDIA GeForce GTX 1050 4 Gb
Almacenamiento | 512 Gb SSD
Sistema operativo | Windows 10 Home 64-bit Edition

***Tabla 3**: Hardware de desarrollo*

**Software**

Nombre | Precio
---- | ----
Sublime Text Editor | Gratuito
Xampp | Gratuito

***Tabla 4**: Software de desarrollo*

**Red**

Tipo | Precio
---- | ----
Dominio en [Nic.cl](https://www.nic.cl/)  | $ 9.950 /año
Hosting | Pronto a seleccionar

***Tabla 5**: Recursos de red*

Debido a los recursos predispuestos, se puede trabajar sin incurrir en costos adicionales; se cuenta con un equipo apropiado para desarrollar bajo las condiciones estipuladas, (Código en PHP) y proveer un ambiente bajo el cuál la aplicación pueda funcionar. Ambos Sublime Text y Xampp son programas de libre acceso, por ende, no se requiere de licencia para ser utilizados como herramienta para programar.

Las preocupaciones monetarias yacen en los temas de Dominio y Hosting; si bien el costo anual puede describirse como mínimo, es importante recalcar que se trata de un gasto que ha de ser considerado por la empresa. La empresa Entretenedores, no obstante, se encuentra actualmente en posesión de un Dominio en nic.cl, por lo cual es posible ignorar este coste durante la implementación de la aplicación.

## 2. Validación de la solución
### 2.1. Validación de la funcionalidad
Este proyecto será evaluado por medio de Pruebas de Aceptación de Usuario. Esto quiere decir que la funcionalidad Aplicación será evaluada por los stakeholders de la empresa, excusando cualquier falla de índole estética (faltas de ortografía o fallas visuales)

Para que el software se considere exitoso, el cliente debería ser capaz de afirmar los siguientes puntos:
* "El software es similar a lo que tenía previsto"
* "El software facilita el proceso de cotización"
* "El software es intuitivo y fácil de comprender"
* "El software ayudará a acelerar mis procesos de negocio"
* "El software cumple con mis expectativas generales"

El éxito del proyecto será evaluado por medio de un cuestionario corto. El cuestionario estará dispuesto de la siguiente forma: para cada una de las afirmaciones listadas anteriormente, el cliente será presentado con cinco opciones: "Muy en desacuerdo", "En desacuerdo", "Neutral", "De acuerdo", y "Fuertemente de acuerdo". Estas opciones corresponden a valores numéricos del 1 al 5; el proyecto será considerado exitoso si el promedio de las respuestas supera a un 4.

El resultado de este test será utilizado como instrumento de retroalimentación, y será considerado un documento de importancia para el proyecto. El documento ofrecerá espacio para que el cliente exprese sus impresiones acerca del sistema por escrito; de esta manera, existirá constancia de los comentarios que tiene la empresa acerca del software en desarrollo.

### 2.2. Validación de la entrega de valor al negocio
![Modelo Canvas](https://github.com/NE-OC/EnterPrice/blob/Order/Informes/Informe%201/Anexos/EnterPrice_Canvas.png)
***Figura 1**: Modelo Canvas* 

# Referencias
* Osterwalder, A. (2005, Noviembre 5). What is a business model? Recuperado desde http://businessmodelalchemist.com/blog/2005/11/what-is-business-model.html
