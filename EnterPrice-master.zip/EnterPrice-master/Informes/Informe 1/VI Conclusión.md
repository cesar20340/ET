# VI: Conclusión
Se cierra este informe recapitulando en las secciones que se llevaron a cabo. Se recalca entonces, la gran importancia que posee la pre-planificación de un proyecto para lograr asegurar su éxito. Muchos problemas pueden ser solventados o esquivados completamente con un plan profundo que no deje incertidumbres ni flaquezas a la hora de ser puesto en marcha.

Es entonces que resulta relevante realizar una investigación minuciosa, cuyo objeto sea vislumbrar detalles del mercado, y cómo el proyecto en cuestión puede afectar los procesos de negocio de la empresa que desea implementar este plan.
No es de menos importancia, sin embargo, aclarar términos relevantes al proyecto, y edificar un puente entre los niveles de conocimiento de ambas partes involucradas. Se entiende mandatorio alcanzar comprensión entre los desarrolladores y la contraparte, buscando lograr afinidad y sintonía total entre los requerimientos impuestos por la empresa, y aquellos comprendidos por el equipo de desarrollo, pues un software, por muy completo y espectacular sea, es completamente inútil si no es lo que el cliente busca.
Naturalmente, sin embargo, el desarrollo es un proceso prolongado y que evoluciona a lo largo del tiempo, por lo que se ve siempre obligado a planificar a futuro con lujo de detalle.

Sin considerar los puntos anteriormente mencionados, desgraciadamente, es inusual que un proyecto resulte exitoso, por lo que se refuerza encarecidamente la necesidad de ésto. Se han tomado estas precauciones en el caso del software en cuestión para la empresa EntreTenedores, por lo que se espera un proceso de desarrollo sin eventualidades o contratiempos mayores.

# VI: Referencias Bibliográficas

* The Apache Software Foundation. (s.f.). About the Apache HTTP Server Project. Recuperado desde http://httpd.apache.org/ABOUT_APACHE.html
* Apache Friends. (s.f.). About the XAMPP project. Recuperado desde https://www.apachefriends.org/es/about.html
* The PHP Group. (s.f.). ¿Qué es PHP? Recuperado desde https://www.php.net/manual/es/intro-whatis.php
* IBM. (s.f.). Acuerdos de nivel de servicio (SLA). Recuperado desde https://www.ibm.com/support/knowledgecenter/es/SSKVFR_7.6.1/com.ibm.spr.doc/sla_spr/c_sla_application.html
* Osterwalder, A. (2005, Noviembre 5). What is a business model? Recuperado desde http://businessmodelalchemist.com/blog/2005/11/what-is-business-model.html
