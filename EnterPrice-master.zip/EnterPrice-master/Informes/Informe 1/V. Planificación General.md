# V. Planificación General
## 1.	Planificación temporal
### 1.1.	 Actividades y tareas
**Fase de desarrollo conceptual**
* **Lluvia de ideas**: Corresponde a la formulación de ideas separadas para determinar cuál es el curso que debe tomar el proyecto.
* **Selección de proyecto**: La determinación de la idea a seguir. Esto implica profundizar en ella y darle forma al proyecto
* **Reunión con empresa**: Corresponde acordar un encuentro con la empresa Entretenedores, para dar cimiento a la idea y concurrir en ideas y detalles relevantes que pudieron ser obviados durante las primeras dos tareas
* **Redacción Informe**: Esta tarea contempla la generación de un informe previo al proyecto

**Fase de planificación**
* **Redacción informe**: El informe actual
* **Reunión con empresa**: Reunión para presentar el progreso actual del informe

**Fase de desarrollo**
* **Definición Layout del sitio**: Esta tarea comprende determinar el aspecto visual del sitio, y la forma que tomará. También comprende la instauración de datos de contacto, así como información de la empresa, tal como Misión, Visión, Quiénes Somos, entre otros.
* **Integración Carrusel de Fotos**: Consiste en integrar la funcionalidad de Carrusel. Esto significa, una imagen solitaria con botones para pasar a distintas imágenes en una rotación predeterminada.
* **Funcionalidad Cotización**: Consiste en programar la funcionalidad para cotizar y establecer los servicios que el usuario puede seleccionar como parte de su evento.
* **Funcionalidad Calendario**: Consiste en programar la habilidad de restringir qué fechas son seleccionables por el usuario, de manera que las fechas que ya cuenten con una reservación sean restringidas

**Fase de depuración y pruebas**
* **Pruebas Funcionales**: Corresponde a realizar pruebas que determinen que el funcionamiento de la aplicación sea el esperado. En otras palabras, la respuesta que la aplicación arroje ante cualquier comando debe encontrarse en sintonía con aquél determinado de forma teórica
* **Pruebas en host**: Consiste en nuevamente llevar a cabo las pruebas en el punto anterior, sin embargo, esta vez en el ambiente de hosting. El propósito de esto es cerciorarse de que los resultados de estas pruebas se encuentren consistentes con aquellos que se obtuvieron en un ambiente de pruebas local
* **Control de calidad**: Se trata de la reprogramación de la aplicación en base a las pruebas que se realizaron. El objetivo de dicha reprogramación es asegurarse de sincronizar los resultados de las pruebas con aquellos esperados

**Fase de implementación y capacitación**
* **Implementación en Host**: Esta tarea corresponde a subir la aplicación al hosting, bajo el dominio previamente adquirido, y dejarla lista y funcional para los usuarios de la empresa.
* **Capacitación empresa**: Consiste en instruir a los trabajadores de Entretenedores en la manera correcta de utilizar la aplicación. Este tutorial debe velar que se entrege información satisfactoria para lograr utilizar la aplicación.

### 1.2.	 Responsables
Los responsables fueron asignados mediante su conocimiento y empatía con las diferentes tareas asignadas por lo cual tanto Nicolás Orellana y César Mansilla constan con lo necesario y con la motivación de aprender cualquier otra solución o nueva forma de trabajar ya sea en el tema de informática o fuera de ella. 

Los responsables fueron relegados a cada tarea dependiendo de su especialización en cada subsector del proyecto. Como regla general, *César Mansilla* fue asignado a tareas correspondientes con la programación del software, mientras que a *Nicolás Orellana* le fueron asignadas las tareas referentes a la documentación del proyecto y contacto con los stakeholders.

Pese a esto, es necesario recalcar que existe un cierto grado de superposición en las tareas, por lo que a menudo es posible ver tareas compartidas, en especial alrededor de tareas que son prerequisito para comenzar otras.

### 1.3.	 Asignación de costos 

**Software**

Nombre | Precio
---- | ----
Sublime Text Editor | Gratuito
Xampp | Gratuito

**Red**

Tipo | Precio
---- | ----
Dominio en [Nic.cl](https://www.nic.cl/)  | $ 9.950 /año
Hosting |Pronto a seleccionar

### 1.4.	 Línea base de seguimiento.
Se usaron como línea base las cinco fases explicadas en el cronograma.

Hito | Fecha Límite
---- | ----
Fase de desarrollo conceptual | 19 de Agosto
Fase de planificación | 3 de Septiembre
Fase de desarrollo | 15 de Octubre
Fase de depuración y pruebas | 29 de Octubre
Fase de implementación y capacitación | 5 de Noviembre

Para más detalle, refiérase a la [***Tabla 1***](https://github.com/NE-OC/EnterPrice/blob/Order/Informes/Informe%201/IV.%20Metodolog%C3%ADa%20de%20Trabajo.md#11-duraci%C3%B3n-y-cronograma) en el apartado IV. Metodología de Desarrollo, 1. Desarrollo de la Solución, 1.1. Duración y cronograma.

### 1.5.	 Carta Gantt
![Carta Gantt](https://github.com/NE-OC/EnterPrice/blob/Order/Informes/Informe%201/Anexos/EnterPrice_Gantt.png)
***Figura 2**: Carta Gantt*
